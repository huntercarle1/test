Timed Random Drops plugin version 0.1.0 by Cirno

DESCRIPTION: This plugin causes each type of block or mob drop to be replaced
with a different one, with the drops being shuffled every five minutes (the
length of time between shuffles can be configured, see USAGE below).

INSTALLATION: To install, just place timed_random_drops.jar in the plugins
folder of a 1.16.4 or 1.16.5 Spigot server. There is no configuration necessary.

USAGE: This plugin is active when loaded. The time between drop shuffles can be
set using the command /shuffle_time followed by the desired number of minutes
between shuffles.
